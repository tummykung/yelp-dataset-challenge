

setClass(
  "learner.failure",
  contains = c("object"),
  representation = representation(
    msg = "character"
  )
)

